load "TinyParser.rb"
parse = Parser.new("input3.tiny")
parse.program()
